#ifndef AISMANIPULATORTYPE_H
#define AISMANIPULATORTYPE_H

enum AisPulseType {
    DifferentialPulse = 0,
    NormalPulse  = 1 ,
    SquarewavePulse = 2
};

#endif // AISMANIPULATORTYPE_H
